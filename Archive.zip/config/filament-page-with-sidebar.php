<?php

return [
    /**
     * number of columns in tailwind grid
     */
    'sidebar_width' => [
        '2xl' => '3',
        'xl' => '3',
        'lg' => '3',
        'md' => '3',
        'sm' => '12',
    ],
];
