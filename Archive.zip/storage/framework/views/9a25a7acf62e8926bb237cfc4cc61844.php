<head>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>
<?php echo e($slot); ?>


<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</body>
<?php /**PATH /Users/sayedmohamed/Sites/alfaMediacal/resources/views/layouts/app.blade.php ENDPATH**/ ?>