<?php

return [
    'certificate' => 'Certificate',
    'certificates' => 'Certificates',
    'confirm_delete_certificate' => 'Are you sure you want to delete this certificate?',
    'confirm_delete_certificates' => 'Are you sure you want to delete these certificates?',
    'create_certificate' => 'Create Certificate',
    'delete_certificate' => 'Delete Certificate',
    'delete_certificates' => 'Delete Certificates',
    'edit_certificate' => 'Edit Certificate',
    'number' => 'Number',
    'show_certificate' => 'Show Certificate',
    'settings' => 'Settings',
    'bulk_import' => 'Bulk Import',
];
