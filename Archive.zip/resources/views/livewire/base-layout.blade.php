<head>
    @livewireStyles
</head>
<body>
{{ $slot }}

@livewireScripts
</body>
