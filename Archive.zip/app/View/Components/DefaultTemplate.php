<?php

namespace App\View\Components;

use Closure;
use Filament\Support\Components\ViewComponent;
use Illuminate\Contracts\View\View;
use Illuminate\View\Component;

class DefaultTemplate extends \Filament\Support\Components\ViewComponent
{
    protected string $view ='components.default-tempalte';


}
